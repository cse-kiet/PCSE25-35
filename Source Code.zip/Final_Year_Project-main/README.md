Step:1 
      Download zip file from Github

Step:2 
      Unzip file in PC

Step:3 
      Follow steps in each README.md file written in each folders. 


## OR 

#Step for Custom_Pointer_&_deatiled_street Folder ----->


            Step:1 
                  Download zip file from Github
            
            Step:2 
                  Unzip file in PC
            
            Step:3 
                  Open index.html

#Step for Detailed_map_all_possiable Folder ----->
                  
            
            Step:1  
                  Download code zip file from github.
            
            Step:2 
                  Unzip code file.
            
            Step:3
                  Navigate to "Detailed_map_all_possiable" 
            
            Step:4 
                  Add a `.env` file or `.env.local` in the project root and specify your API key as `REACT_APP_GOOGLE_MAPS_API_KEY=your_api_key_here`
            
            Step:5
                   you can run:
            
                   ```
                   yarn install
                   yarn start
                   ```
            
                   OR using npm
            
                   ```
                   npm install
                   npm start
                   ```

#Step for Top_rating_schl_hotel_etc_feedback Folder ----->


            Step:1 
                  Download zip file from Github
            
            Step:2 
                  Unzip file in PC
            
            Step:3 
                  Open index.html

                   
            


