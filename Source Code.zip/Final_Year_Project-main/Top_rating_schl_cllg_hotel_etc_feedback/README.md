Step:1 
      Download zip file from Github

Step:2 
      Unzip file in PC

Step:3 
      Open index.html
